package Ifsc;

public class MainVeiculo {

	public static void main(String[] args) {

		veiculo carro = new veiculo();

		carro.setNome("celta");
		carro.setCor("Vermelho");
		carro.setAno(2025);

	}

}
