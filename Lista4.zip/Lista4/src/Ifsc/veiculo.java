package Ifsc;

public class veiculo {

	private Integer Ano;
	private String Nome;
	private Integer Rodas;
	private String Fabricante;
	private String Cor;

	public Integer getAno() {
		return Ano;
	}

	public void setAno(Integer ano) {
		Ano = ano;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String nome) {
		Nome = nome;
	}

	public Integer getRodas() {
		return Rodas;
	}

	public void setRodas(Integer rodas) {
		Rodas = rodas;
	}

	public String getFabricante() {
		return Fabricante;
	}

	public void setFabricante(String fabricante) {
		Fabricante = fabricante;
	}

	public String getCor() {
		return Cor;
	}

	public void setCor(String cor) {
		Cor = cor;
	}

}
